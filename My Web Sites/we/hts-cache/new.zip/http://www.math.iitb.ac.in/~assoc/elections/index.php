<!DOCTYPE html>

<html>

<head>
  <title>Elections | Mathematics</title>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta charset="UTF-8">
  <meta name="description" content="Elections Mathematics Association 2018">
  <meta name="keywords" content="Elections, elections 2018, Elections Math, math iit bombay">
  <meta name="author" content="Abhishek Guha">

  <!-- Facebook Open Graph -->
  <meta property="og:title" content="Elections 2018"/>
  <meta property="og:image" content="http://www.math.iitb.ac.in/~assoc/mo/images/logo1.gif"/>
  <meta property="og:site_name" content="Math Assoc Elections 2017"/>
  <meta property="og:description" content="Mathematics Association Elections 2018, Department of Mathematics IIT Bombay"/>
	

  <!-- Mobile support -->
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Material Design fonts -->
  <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:300,400,500,700" type="text/css">
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

  <!-- Bootstrap -->
  <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet">

  <!-- Bootstrap Material Design -->
  <link href="css/bootstrap-material-design.css" rel="stylesheet">
  <link href="css/ripples.min.css" rel="stylesheet">

  <!-- Dropdown.js -->
  <link href="//cdn.rawgit.com/FezVrasta/dropdown.js/master/jquery.dropdown.css" rel="stylesheet">

  <!-- Page style -->
  <link href="index.css" rel="stylesheet">

  <!-- jQuery -->
  <script src="//code.jquery.com/jquery-1.10.2.min.js"></script>

</head>

<body>

<!-- ****** NAVBAR ****** -->

<div class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-responsive-collapse">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="javascript:void(0)">Elections 2018</a>
    </div>
    <div class="navbar-collapse collapse navbar-responsive-collapse">
      <ul class="nav navbar-nav">
        <li class="active"><a href="index.php">Home</a></li>
	<li><a href="results.php">Results</a></li>
	<li><a href="../">Assoc</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="http://www.math.iitb.ac.in">Department of Mathematics</a></li>
        <li><a href="http://www.iitb.ac.in">IIT Bombay </a></li>
      </ul>
    </div>
  </div>
</div>

<!-- ******** BODY ******* -->

<div class="container">

<div class="row">
      <div class="col-md-8 col-md-offset-2">

        <div class="bs-component">
          <div class="alert alert-success">
            <h2>Welcome to Mathematics Association, Elections 2018</h2>

            <br>
            <h3 class="text-danger">Election <a href="results.php" style="text-decoration:none">result</a> declared</h3>
            <br>
	    <br>
            <p>Candidates with their manifesto and contesting positions are listed below.</p>
          </div>
        </div>
      </div>
</div>



<div class="row">
      <div class="col-md-10 col-md-offset-1">
        <div class="bs-component">
          <div class="panel panel-primary">
            <div class="panel-heading">
              <h3 class="panel-title text-center"><b>General Secretary</b></h3>
            </div>
            <div class="panel-body">
			  <div class="col-md-2"></div>
   			  <div class="col-md-6">
              <img class="img-responsive" src="Elections 18-19/Akshay.jpg" width="90" height="90">
              <h4>Akshay Singla</h4><br>
              <a href="Elections 18-19/Manifesto_AKSHAY_SINGLA.pdf" style="text-decoration: none">Manifesto</a>
              </div>

			  <div class="col-md-4">
              <img class="img-responsive" src="Elections 18-19/Shefali Gambhir.JPG" width="90" height="90">
              <h4>Shefali Gambhir</h4><br>
              <a href="Elections 18-19/Manifesto_Shefali.pdf" style="text-decoration: none">Manifesto</a>
              </div>

            </div>
          </div>

          <div class="panel panel-primary">
            <div class="panel-heading">
              <h3 class="panel-title text-center"><b>Cultural Secretary</b></h3>
            </div>
              <div class="panel-body">
			  <div class="col-md-5"></div>
   			  <div class="col-md-5">
              <img class="img-responsive" src="Elections 18-19/Taniya_Sarkar.jpg" width="90" height="90">
              <h4>Taniya Sarkar</h4><br>
              <a href="Elections 18-19/MANIFESTO_Taniya.pdf" style="text-decoration: none">Manifesto</a>
              </div> 
              </div> 
          </div>

          <div class="panel panel-primary">
            <div class="panel-heading">
              <h3 class="panel-title text-center"><b>Sports Secretary</b></h3>
            </div>
            <div class="panel-body">
			  <div class="col-md-2"></div>
   			  <div class="col-md-6">
              <img class="img-responsive" src="Elections 18-19/Ranjan Sharma.jpeg" width="90" height="90">
              <h4>Ranjan Sharma</h4><br>
              <a href="Elections 18-19/Manifesto_Ranjan_Sharma.PDF" style="text-decoration: none">Manifesto</a>
              </div>

			  <div class="col-md-4">
              <img class="img-responsive" src="Elections 18-19/Saransh.jpeg" width="90" height="90">
              <h4>Saransh Lohiya</h4><br>
              <a href="Elections 18-19/Manifesto_Saransh.pdf" style="text-decoration: none">Manifesto</a>
              </div>
              </div>
          </div>

          <div class="panel panel-primary">
            <div class="panel-heading">
              <h3 class="panel-title text-center"><b>Web and Design Secretary</b></h3>
            </div>
            <div class="panel-body">
			  <div class="col-md-2"></div>
   			  <div class="col-md-6">
              <img class="img-responsive" src="Elections 18-19/Prasanjit.jpg" width="90" height="90">
              <h4>Prasanjit Dubey</h4><br>
              <a href="Elections 18-19/MANIFESTO_Prasanjit.pdf" style="text-decoration: none">Manifesto</a>
              </div>

			  <div class="col-md-4">
              <img class="img-responsive" src="Elections 18-19/Rakesh.jpg" width="90" height="90">
              <h4>Rakesh Saini</h4><br>
              <a href="Elections 18-19/Manifesto_Rakesh Saini.pdf" style="text-decoration: none">Manifesto</a>
              </div>
            </div>
          </div>

          <div class="panel panel-primary">
            <div class="panel-heading">
              <h3 class="panel-title text-center"><b>Alumni Secretary</b></h3>
            </div>
            <div class="panel-body">
			  <div class="col-md-5"></div>
   			  <div class="col-md-5">
              <img class="img-responsive" src="Elections 18-19/Rajesh.jpg" width="90" height="90">
              <h4>Rajesh Kumar</h4><br>
              <a href="Elections 18-19/MANIFESTO_Rajesh.pdf" style="text-decoration: none">Manifesto</a>
              </div>
            </div>
          </div>

          <div class="panel panel-primary">
            <div class="panel-heading">
              <h3 class="panel-title text-center"><b>Assistant Treasurer</b></h3>
            </div>
            <div class="panel-body">
			  <div class="col-md-2"></div>
   			  <div class="col-md-6">
              <img class="img-responsive" src="Elections 18-19/APURBA SARKAR.jpg" width="90" height="90">
              <h4>Apurba Sarkar</h4><br>
              <a href="Elections 18-19/Manifesto_Apurba.pdf" style="text-decoration: none">Manifesto</a>
              </div>

			  <div class="col-md-4">
              <img class="img-responsive" src="Elections 18-19/Lokesh Arya.JPG" width="90" height="90">
              <h4>Lokesh Arya</h4><br>
              <a href="Elections 18-19/Manifesto_Lokesh_Arya.pdf" style="text-decoration: none">Manifesto</a>
              </div>
            </div>
          </div>

		  <div class="panel panel-primary">
            <div class="panel-heading">
              <h3 class="panel-title text-center"><b>Department Placement Coordinator, ASI</b></h3>
            </div>
              <div class="panel-body">
			  <div class="col-md-5"></div>
   			  <div class="col-md-5">
              <img class="img-responsive" src="Elections 18-19/Devesh.jpg" width="90" height="90">
              <h4>Devesh Agrawal</h4><br>
              <a href="Elections 18-19/Manifesto_Devesh.pdf" style="text-decoration: none">Manifesto</a>
              </div>
            </div>
          </div>

          <div class="panel panel-primary">
            <div class="panel-heading">
              <h3 class="panel-title text-center"><b>Department Placement Coordinator, Maths</b></h3>
            </div>
              <div class="panel-body">
			  <div class="col-md-5"></div>
   			  <div class="col-md-5">
              <img class="img-responsive" src="Elections 18-19/megha.jpg" width="90" height="90">
              <h4>Megha Berlia</h4><br>
              <a href="Elections 18-19/Manifesto_Megha.pdf" style="text-decoration: none">Manifesto</a>
              </div> 
              </div> 
          </div>
    
          <div class="panel panel-primary">
            <div class="panel-heading">
              <h3 class="panel-title text-center"><b>Class Representative, Maths</b></h3>
            </div>
            <div class="panel-body">
			  <div class="col-md-5"></div>
   			  <div class="col-md-5">
              <img class="img-responsive" src="Elections 18-19/Makadiya Deep.jpg" width="90" height="90">
              <h4>Makadiya Deepkumar Hasamukhbhai</h4><br>
              <a href="Elections 18-19/Manifesto_Makadiya_Deepkumar.pdf" style="text-decoration: none">Manifesto</a>
              </div>
            </div>
          </div>


            </div>
          </div>

        </div>
      </div>
    </div>

</div>

</body>
</html>